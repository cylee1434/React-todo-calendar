import React, {useState} from 'react';
import { MdAddCircle } from 'react-icons/md';
import Template from './components/Template';
import TodoInsert from './components/TodoInsert';
import TodoList from './components/TodoList';
import './App.css';
import Calendar from 'react-calendar';
import Example from './components/calendar';
// import { render } from "react-dom";

let nextId = 4;

const App = () => {
  const [selectedTodo, setSelectedTodo] = useState(null);
  const [insertToggle, setInsertToggle] = useState(false);
  const [todos, setTodos] = useState([
    {
      id: 1,
      text: '일정관리1',
      checked: true,
    },
    {
      id: 2,
      text: '일정관리2',
      checked: true,
    },
    {
      id: 3,
      text: '일정관리3',
      checked: false,
    },
  ]);

  const onInsertToggle = () => {
    if (selectedTodo) {
      setSelectedTodo(null);
   }
    setInsertToggle(prev => !prev)
  }

  const onInsertTodo =  text => {
    if (text === "") {
      return alert('일정을 등록해주세요!')
    } else {
      const todo = {
        id: nextId,
        text,
        checked: false
      }
      setTodos(todos => todos.concat(todo));
      nextId++;
    }
  }

  const onCheckToggle = (id) => {
    setTodos(todos =>
      todos.map(todo =>
        todos.id === id ? { ...todo, checked: !todo.checked } : todo
      )
    );
  };

  const onChangesetSelectedTodo = (todo) => {
    setSelectedTodo(todo)
  }

  const onRemove = id => {
    onInsertToggle();
    setTodos(todos => todos.filter(todo=>todo.id !== id))
  }

  const onUpdate = (id, text) => {
    onInsertToggle();
    setTodos(todos => todos.map(todo => todo.id === id ? { ...todo, text } : todo))
  };

  const ReactCalendar = () => {
    const [date, setDate] = useState(new Date());
    const onChange = date => {
      setDate(date);
    };
  
 

    return (
      <div>
        <Calendar onChange={onChange} value={date} />
      </div>
    );
  };
  
  // render(<ReactCalendar />, document.querySelector("#root"));

  return (
    <Template todoLength={todos.length}>
    <ReactCalendar Example = {Example}/>
      <TodoList
        todos={todos}
        onCheckToggle={onCheckToggle}
        onInsertToggle={onInsertToggle}
        onChangesetSelectedTodo = {onChangesetSelectedTodo}
      />
      <div className="add-todo-button" onClick={onInsertToggle}><MdAddCircle/></div>
      {insertToggle && (
        <TodoInsert
          selectedTodo={selectedTodo}
          onInsertToggle={onInsertToggle}
          onInsertTodo={onInsertTodo}
          onRemove={onRemove}
          onUpdate={onUpdate}
          Example = {Example}
        />
      )}
    </Template>
  );
}

export default App;